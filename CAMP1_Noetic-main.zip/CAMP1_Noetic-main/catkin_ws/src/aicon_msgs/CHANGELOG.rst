^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package aicon_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2022-07-20)
------------------
* Noetic package release
* Created based on ROBOTIS Code
* Contributors: Yejin Choi
