^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package aicon_camp1_camera
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2023-05-01)
------------------
* Noetic package release
* Control CAMP V1.
* Created based on ROBOTIS Code
* Contributors: Yejin Choi
